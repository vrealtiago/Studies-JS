
function insertScore() {
    var bodyTable = $(".score").find("tbody");
    var username = "seu nome";
    var numWord = $("#ctPhrase").text()
    var line = newLine(username, numWord);
    line.find(".btnRemove").click(removeLine)
    bodyTable.append(line);
}

function newLine(user, word) {
    var line = $("<tr>");
    var colUser = $("<td>").text(user);
    var colWord = $("<td>").text(word);
    var colRemove = $("<td>");

    var link = $("<a>").attr("href", "#").addClass("btnRemove");
    var icon = $("<i>").addClass("small").addClass("material-icons").text("delete");

    link.append(icon);

    colRemove.append(link);

    line.append(colUser);
    line.append(colWord);
    line.append(colRemove);
    return line;

};

function removeLine() {
    event.preventDefault();
    $(this).parent().parent().remove();
}

function removeLinha() {
    event.preventDefault();
    $(this).parent().parent().remove();
}