$("#tLeft").text(10);
var initTime = $("#tLeft").text();

var fieldTxt = $(".typeField");

$(function () {
    updateSizePhrase();
    ctWordChar();
    initChronometre();
    initScore();
    $("#restartGame").click(restartGame);
});


function updateSizePhrase() {
    var phrase = $(".phrase").text();
    var countPhrase = phrase.split(" ").length;
    $("#nPhrase").text(countPhrase);
}


function ctWordChar() {
    fieldTxt.on("input", function () {
        var qtyPhrased = fieldTxt.val().split(/\S+/).length - 1;
        var qtyChar = fieldTxt.val().replace(/\s+/g,'').length;
        $("#ctPhrase").text(qtyPhrased);
        $("#ctChar").text(qtyChar);
    });
}

function initChronometre() {
    var timeLeft = initTime;
    fieldTxt.one("focus", function () {
        $("#restartGame").attr("disabled", true);
        var chronometreID = setInterval(function () {
            timeLeft --;
            $("#tLeft").text(timeLeft);
            if(timeLeft < 1){
                clearInterval(chronometreID);
                endGame();
            }
        }, 1000)

    });
}

function endGame() {
    fieldTxt.attr("disabled", true);
    fieldTxt.toggleClass("disabledField");
    insertScore();
}

function initScore() {
    var phrase = $(".phrase").text();
    fieldTxt.on("input", function () {
        var typed = fieldTxt.val();
        if (phrase.startsWith(typed)) {
            fieldTxt.addClass("greenBorder");
            fieldTxt.removeClass("redBorder");
        } else {
            fieldTxt.addClass("redBorder");
            fieldTxt.removeClass("greenBorder");
        }
    });
}

$("#restartGame").click(restartGame);
function restartGame() {
    fieldTxt.attr("disabled", false);
    fieldTxt.val("");
    $("#ctPhrase").text("0");
    $("#ctChar").text("0");
    $("#tLeft").text(initTime);
    initChronometre();
    fieldTxt.toggleClass("disabledField");
    fieldTxt.removeClass("redBorder");
    fieldTxt.removeClass("greenBorder");
}